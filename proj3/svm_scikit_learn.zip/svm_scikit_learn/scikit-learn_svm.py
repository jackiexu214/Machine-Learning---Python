from sklearn import svm
import numpy as np
from scipy.io import loadmat

# load dataset
mat = loadmat("Breast_Tissue.mat");
data = mat.get("data");
label = mat.get("label").ravel();
n_sample, n_feature = data.shape;

dtemp = np.zeros((n_sample, n_feature+1));
dtemp[:,0:n_feature] = data;
dtemp[:,n_feature] = label;
drp = np.random.permutation(dtemp);

train_label = drp[0:n_sample-10,n_feature];
train_data = drp[0:n_sample-10,0:n_feature];
test_label = drp[n_sample-10:n_sample,n_feature];
test_data = drp[n_sample-10:n_sample,0:n_feature];

clf = svm.SVC(kernel='rbf', gamma=1, C=10);
clf.fit(train_data,train_label);

predicted_label = clf.predict(test_data);
print('\n Test set Accuracy:' + str(100*np.mean((predicted_label == test_label).astype(float))) + '%');

clf = svm.SVC(kernel='linear', C=10);
clf.fit(train_data,train_label);

predicted_label = clf.predict(test_data);
print('\n Test set Accuracy:' + str(100*np.mean((predicted_label == test_label).astype(float))) + '%');

# Get support vectors
print(clf.support_vectors_)